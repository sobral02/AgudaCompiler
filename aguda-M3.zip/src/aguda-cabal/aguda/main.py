import sys
import os
from lexer import lexer
from parser import parser
from errors import LexicalError, SemanticError, SyntaxError
from validator import Validator  # NOVO
import pretty_printer  # Podes deixar isto se quiseres ver a AST (opcional)

def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 main.py <source_file.agu>")
        sys.exit(1)

    filename = sys.argv[1]

    try:
        source_code = read_file(filename)

       

        # Reset de novo o input para que o parser possa usá-lo
        lexer.input(source_code)
    

        # Parse e construção da AST
        ast_root = parser.parse(source_code, lexer=lexer)

        # (Opcional) imprime AST antes de validar
        

        # Validação semântica
        validator = Validator(max_errors=5)  # valor ajustável, nuca deve ser 0!
        validator.source_lines = source_code.splitlines()
        validator.validate(ast_root)
        
        pretty_printer.print_ast(ast_root)
        
        print("\n")

        print("Valid!")  # Se não houve erro

    except LexicalError as e:
        print(f"Lexical Error: {e}")
        sys.exit(1)

    except SyntaxError as e:
        print(f"Syntax Error: {e}")
        sys.exit(1)

    except SemanticError as e:
        print(f"Semantic Error: {e}")
        sys.exit(1)

    except FileNotFoundError:
        print(f"File not found: {filename}")
        sys.exit(1)

if __name__ == "__main__":
    main()
