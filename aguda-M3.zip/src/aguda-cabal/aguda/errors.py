

class LexicalError(Exception):
    pass

class SyntaxError(Exception):
    pass

class SemanticError(Exception): 
    pass
